// The contents of this file are dedicated to the public domain.
// (See http://creativecommons.org/publicdomain/zero/1.0/)

interface IAgent
{
	void reset();
	void update(Model m);
}
