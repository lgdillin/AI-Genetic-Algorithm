#!/bin/bash
javac *.java
